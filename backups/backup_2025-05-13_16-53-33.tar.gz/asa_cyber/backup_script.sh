#!/bin/bash

# Configuració
SOURCE_DIR="/workspaces/asa_cyber"
BACKUP_DIR="/workspaces/asa_cyber/backups"
LOG_FILE="/workspaces/asa_cyber/backups/backup.log"
DATE=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_FILE="$BACKUP_DIR/backup_$DATE.tar.gz"  # Nombre del archivo de respaldo

# Crear directorio de respaldo si no existe
if [ ! -d "$BACKUP_DIR" ]; then
    mkdir -p "$BACKUP_DIR"
fi

# Crear directorio de logs si no existe
LOG_DIR=$(dirname "$LOG_FILE")
if [ ! -d "$LOG_DIR" ]; then
    mkdir -p "$LOG_DIR"
fi

# Simular pensament
echo "[$(date +"%Y-%m-%d %H:%M:%S")] Preparant la còpia de seguretat..." | tee -a "$LOG_FILE"
sleep 2
echo "[$(date +"%Y-%m-%d %H:%M:%S")] Analitzant els fitxers i directoris..." | tee -a "$LOG_FILE"
sleep 3
echo "[$(date +"%Y-%m-%d %H:%M:%S")] Començant la compressió dels fitxers..." | tee -a "$LOG_FILE"
sleep 2

# Realitzar la còpia de seguretat
if tar -czf "$BACKUP_FILE" -C "$(dirname "$SOURCE_DIR")" "$(basename "$SOURCE_DIR")"; then
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] Copia de seguretat completada: $BACKUP_FILE" | tee -a "$LOG_FILE"
else
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] Error al realitzar la còpia de seguretat." | tee -a "$LOG_FILE"
    exit 1
fi

# Simular finalització
echo "[$(date +"%Y-%m-%d %H:%M:%S")] Finalitzant el procés de còpia de seguretat..." | tee -a "$LOG_FILE"
sleep 2
echo "[$(date +"%Y-%m-%d %H:%M:%S")] Procés de còpia de seguretat finalitzat." | tee -a "$LOG_FILE"